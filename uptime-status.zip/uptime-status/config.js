window.Config = {

  // 显示标题
  SiteName: 'Jgwy Public Status',

  // UptimeRobot Api Keys
  // 支持 Monitor-Specific 和 Read-Only
  ApiKeys: [
    'ur2345635-7c4bd3e8dd3207f551765172',
   ],

  // 日志天数
  CountDays: 90,

  // 是否显示检测站点的链接
  ShowLink: true,

  // 导航栏菜单
  Navi: [
    {
      text: 'Homepage',
      url: 'https://jgwy.com/'
    },
    {
      text: 'GitHub',
      url: 'https://github.com/jgwycom/uptime-status'
    },
    {
      text: 'Blog',
      url: 'https://jglt.net/'
    },
  ],
};
